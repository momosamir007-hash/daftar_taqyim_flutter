import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const DaftarTaqyimApp());
}

class DaftarTaqyimApp extends StatelessWidget {
  const DaftarTaqyimApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'دفتر التقييم الرقمي',
    theme: ThemeData(
      useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF176B5B)),
      fontFamily: 'Roboto', scaffoldBackgroundColor: const Color(0xFFF5F7F6),
      appBarTheme: const AppBarTheme(centerTitle: false, backgroundColor: Color(0xFFF5F7F6)),
      inputDecorationTheme: InputDecorationTheme(border: OutlineInputBorder(borderRadius: BorderRadius.circular(14))),
    ),
    builder: (context, child) => Directionality(textDirection: TextDirection.rtl, child: child!),
    home: const HomeScreen(),
  );
}
