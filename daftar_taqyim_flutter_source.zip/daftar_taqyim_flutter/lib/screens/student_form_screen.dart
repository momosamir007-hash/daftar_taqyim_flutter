import 'package:flutter/material.dart';
import '../data/local_database.dart';
import '../models/student.dart';

class StudentFormScreen extends StatefulWidget { const StudentFormScreen({super.key, this.student}); final Student? student; @override State<StudentFormScreen> createState() => _StudentFormScreenState(); }
class _StudentFormScreenState extends State<StudentFormScreen> {
  final _form = GlobalKey<FormState>(); late final TextEditingController _name, _dob, _id, _class, _notes; String _gender = 'غير محدد'; bool _saving = false;
  @override void initState() { super.initState(); final s = widget.student; _name = TextEditingController(text: s?.name ?? ''); _dob = TextEditingController(text: s?.birthDate ?? ''); _id = TextEditingController(text: s?.nationalId ?? ''); _class = TextEditingController(text: s?.className ?? 'القسم التحضيري'); _notes = TextEditingController(text: s?.notes ?? ''); _gender = s?.gender ?? 'غير محدد'; }
  @override void dispose() { _name.dispose(); _dob.dispose(); _id.dispose(); _class.dispose(); _notes.dispose(); super.dispose(); }
  Future<void> _save() async { if (!_form.currentState!.validate()) return; setState(() => _saving = true); final old = widget.student; final now = DateTime.now().toIso8601String(); final s = Student(id: old?.id ?? LocalDatabase.instance.newId(), name: _name.text.trim(), birthDate: _dob.text.trim(), gender: _gender, className: _class.text.trim().isEmpty ? 'القسم التحضيري' : _class.text.trim(), nationalId: _id.text.trim(), notes: _notes.text.trim(), evaluations: old?.evaluations ?? {}, history: old?.history ?? [], legacy: old?.legacy ?? {}, createdAt: old?.createdAt ?? now, updatedAt: now); await LocalDatabase.instance.saveStudent(s); if (mounted) Navigator.pop(context); }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: Text(widget.student == null ? 'تسجيل تلميذ جديد' : 'تعديل بيانات التلميذ')), body: Form(key: _form, child: ListView(padding: const EdgeInsets.all(16), children: [
    TextFormField(controller: _name, decoration: const InputDecoration(labelText: 'الاسم واللقب *', prefixIcon: Icon(Icons.person_outline)), validator: (v) => v == null || v.trim().isEmpty ? 'أدخل اسم التلميذ' : null),
    const SizedBox(height: 12), TextFormField(controller: _class, decoration: const InputDecoration(labelText: 'القسم / المستوى', prefixIcon: Icon(Icons.class_outlined))),
    const SizedBox(height: 12), TextFormField(controller: _dob, decoration: const InputDecoration(labelText: 'تاريخ الميلاد (YYYY-MM-DD)', prefixIcon: Icon(Icons.cake_outlined))),
    const SizedBox(height: 12), DropdownButtonFormField<String>(value: _gender, decoration: const InputDecoration(labelText: 'الجنس'), items: const [DropdownMenuItem(value: 'غير محدد', child: Text('غير محدد')), DropdownMenuItem(value: 'ذكر', child: Text('ذكر')), DropdownMenuItem(value: 'أنثى', child: Text('أنثى'))], onChanged: (v) => setState(() => _gender = v ?? 'غير محدد')),
    const SizedBox(height: 12), TextFormField(controller: _id, decoration: const InputDecoration(labelText: 'رقم التعريف / التسجيل', prefixIcon: Icon(Icons.badge_outlined))),
    const SizedBox(height: 12), TextFormField(controller: _notes, minLines: 2, maxLines: 4, decoration: const InputDecoration(labelText: 'ملاحظات', alignLabelWithHint: true)),
    const SizedBox(height: 24), FilledButton.icon(onPressed: _saving ? null : _save, icon: const Icon(Icons.save_outlined), label: Text(_saving ? 'جارٍ الحفظ...' : 'حفظ البيانات')),
  ])));
}
