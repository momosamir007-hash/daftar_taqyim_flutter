import 'package:flutter/material.dart';
import '../data/local_database.dart';
import '../models/student.dart';
import 'student_detail_screen.dart';
import 'student_form_screen.dart';

class StudentsScreen extends StatefulWidget { const StudentsScreen({super.key}); @override State<StudentsScreen> createState() => _StudentsScreenState(); }
class _StudentsScreenState extends State<StudentsScreen> {
  final _search = TextEditingController(); String _classFilter = ''; List<Student> _students = []; List<String> _classes = []; bool _loading = true;
  @override void initState() { super.initState(); _load(); _search.addListener(_load); }
  @override void dispose() { _search.dispose(); super.dispose(); }
  Future<void> _load() async { final db = LocalDatabase.instance; final rows = await db.getStudents(query: _search.text, className: _classFilter); final classes = await db.getClasses(); if (mounted) setState(() { _students = rows; _classes = classes; _loading = false; }); }
  Future<void> _open(Student s) async { await Navigator.push(context, MaterialPageRoute(builder: (_) => StudentDetailScreen(studentId: s.id))); _load(); }
  Future<void> _add() async { await Navigator.push(context, MaterialPageRoute(builder: (_) => const StudentFormScreen())); _load(); }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('قائمة التلاميذ')),
    floatingActionButton: FloatingActionButton.extended(onPressed: _add, icon: const Icon(Icons.person_add_alt_1), label: const Text('إضافة تلميذ')),
    body: Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(16, 8, 16, 8), child: TextField(controller: _search, decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'ابحث بالاسم أو رقم التعريف', filled: true, fillColor: Colors.white))),
      if (_classes.isNotEmpty) SizedBox(height: 48, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12), children: [ChoiceChip(label: const Text('كل الأقسام'), selected: _classFilter.isEmpty, onSelected: (_) { setState(() => _classFilter = ''); _load(); }), ..._classes.map((c) => Padding(padding: const EdgeInsetsDirectional.only(start: 6), child: ChoiceChip(label: Text(c), selected: _classFilter == c, onSelected: (_) { setState(() => _classFilter = c); _load(); }))) ])),
      Expanded(child: _loading ? const Center(child: CircularProgressIndicator()) : _students.isEmpty ? const Center(child: Text('لا توجد سجلات مطابقة. أضف تلميذًا للبدء.')) : ListView.separated(padding: const EdgeInsets.fromLTRB(12, 8, 12, 90), itemCount: _students.length, separatorBuilder: (_, __) => const SizedBox(height: 4), itemBuilder: (context, i) { final s = _students[i]; return Card(child: ListTile(onTap: () => _open(s), leading: CircleAvatar(child: Text(s.name.trim().isEmpty ? '؟' : String.fromCharCode(s.name.trim().runes.first))), title: Text(s.name, style: const TextStyle(fontWeight: FontWeight.w600)), subtitle: Text('${s.className} • ${s.gender}'), trailing: const Icon(Icons.chevron_left))); })),
    ]),
  );
}
