import 'dart:io';
import 'dart:convert';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../data/local_database.dart';
import '../models/student.dart';
import 'student_form_screen.dart';
import 'students_screen.dart';

class HomeScreen extends StatefulWidget { const HomeScreen({super.key}); @override State<HomeScreen> createState() => _HomeScreenState(); }
class _HomeScreenState extends State<HomeScreen> {
  int _count = 0; List<String> _classes = []; bool _busy = false;
  @override void initState() { super.initState(); _refresh(); }
  Future<void> _refresh() async { final c = await LocalDatabase.instance.countStudents(); final cl = await LocalDatabase.instance.getClasses(); if (mounted) setState(() { _count = c; _classes = cl; }); }
  Future<void> _add() async { await Navigator.push(context, MaterialPageRoute(builder: (_) => const StudentFormScreen())); _refresh(); }
  Future<void> _import() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['json'], withData: true);
    if (result == null) return;
    try {
      final bytes = result.files.single.bytes ?? await File(result.files.single.path!).readAsBytes();
      final report = await LocalDatabase.instance.importJson(utf8.decode(bytes));
      await _refresh(); if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تم الاستيراد: ${report['added']} جديد، ${report['updated']} محدّث')));
    } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر استيراد الملف: $e'))); }
  }
  Future<void> _backup() async {
    setState(() => _busy = true);
    try {
      final json = await LocalDatabase.instance.exportJson();
      final dir = await getTemporaryDirectory(); final file = File('${dir.path}/backup_daftar_taqyim_${DateTime.now().millisecondsSinceEpoch}.json');
      await file.writeAsString(json, flush: true);
      await Share.shareXFiles([XFile(file.path)], text: 'نسخة احتياطية من دفتر التقييم الرقمي');
    } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر إنشاء النسخة: $e'))); }
    if (mounted) setState(() => _busy = false);
  }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('دفتر التقييم الرقمي', style: TextStyle(fontWeight: FontWeight.bold)), actions: [IconButton(onPressed: _import, tooltip: 'استيراد نسخة قديمة', icon: const Icon(Icons.file_open_outlined))]),
    body: RefreshIndicator(onRefresh: _refresh, child: ListView(padding: const EdgeInsets.all(16), children: [
      Container(padding: const EdgeInsets.all(22), decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF145B50), Color(0xFF278A72)]), borderRadius: BorderRadius.circular(22)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('مساحة الأستاذ الخاصة', style: TextStyle(color: Colors.white70)), const SizedBox(height: 8),
        const Text('كل بياناتك على هاتفك،\nوتعمل دون اتصال بالإنترنت.', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 18), Row(children: [const Icon(Icons.people_alt_outlined, color: Colors.white), const SizedBox(width: 8), Text('$_count تلميذ مسجل', style: const TextStyle(color: Colors.white, fontSize: 16))]),
      ])),
      const SizedBox(height: 18), Row(children: [Expanded(child: _stat('التلاميذ', '$_count', Icons.groups_2_outlined)), const SizedBox(width: 10), Expanded(child: _stat('الأقسام', '${_classes.length}', Icons.class_outlined))]),
      const SizedBox(height: 20), const Text('إدارة البيانات', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), const SizedBox(height: 10),
      _action(Icons.person_add_alt_1, 'إضافة تلميذ', 'تسجيل فردي لبيانات التلميذ', _add),
      _action(Icons.people_outline, 'قائمة التلاميذ', 'البحث والتعديل وفتح بطاقة التلميذ', () async { await Navigator.push(context, MaterialPageRoute(builder: (_) => const StudentsScreen())); _refresh(); }),
      _action(Icons.file_upload_outlined, 'استيراد بيانات قديمة', 'استيراد students_data.json أو نسخة التطبيق', _import),
      _action(Icons.backup_outlined, 'نسخة احتياطية', 'تصدير جميع البيانات في ملف JSON', _busy ? null : _backup),
      const SizedBox(height: 12), Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: const Color(0xFFE8F2EF), borderRadius: BorderRadius.circular(16)), child: const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(Icons.lock_outline, color: Color(0xFF176B5B)), SizedBox(width: 10), Expanded(child: Text('البيانات محفوظة محليًا داخل التطبيق. احفظ نسخة احتياطية بانتظام، ولا تحذف التطبيق قبل تصدير بياناتك.', style: TextStyle(height: 1.5))) ])),
    ])),
  );
  Widget _stat(String label, String value, IconData icon) => Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, color: const Color(0xFF176B5B)), const SizedBox(height: 8), Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)), Text(label, style: const TextStyle(color: Colors.black54))])));
  Widget _action(IconData icon, String title, String subtitle, VoidCallback? onTap) => Card(child: ListTile(onTap: onTap, leading: CircleAvatar(backgroundColor: const Color(0xFFE8F2EF), child: Icon(icon, color: const Color(0xFF176B5B))), title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)), subtitle: Text(subtitle), trailing: const Icon(Icons.chevron_left)));
}
