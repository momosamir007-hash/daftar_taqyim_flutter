import 'package:flutter/material.dart';
import '../data/local_database.dart';
import '../models/student.dart';
import 'student_form_screen.dart';

const Map<String, List<String>> defaultAcademic = {
  'اللغة العربية': ['القراءة', 'الكتابة', 'التواصل الشفهي', 'الفهم والاستيعاب'],
  'الرياضيات': ['الأعداد والحساب', 'الهندسة والفضاء', 'القياس', 'حل المسائل'],
  'التربية الإسلامية': ['حفظ القرآن', 'الفهم والاستيعاب', 'السيرة والآداب'],
  'التربية العلمية': ['اكتشاف المحيط', 'البيئة والطبيعة'],
};
const Map<String, Map<String, List<String>>> defaultBehavior = {
  'المهارات الاجتماعية والشخصية': {
    'التفاعل والاندماج': ['المشاركة مع الأقران', 'العمل الجماعي', 'احترام القواعد'],
    'الاستقلالية': ['الاعتماد على النفس', 'إدارة الأدوات المدرسية', 'المبادرة'],
  },
  'المهارات المعرفية والحركية': {
    'التركيز والانتباه': ['الانتباه أثناء الدرس', 'إنجاز المهمة المطلوبة'],
    'التناسق الحركي': ['التحكم في القلم', 'الأنشطة اليدوية'],
  },
};

class StudentDetailScreen extends StatefulWidget { const StudentDetailScreen({super.key, required this.studentId}); final String studentId; @override State<StudentDetailScreen> createState() => _StudentDetailScreenState(); }
class _StudentDetailScreenState extends State<StudentDetailScreen> {
  Student? _student; bool _loading = true;
  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async { final s = await LocalDatabase.instance.getStudent(widget.studentId); if (mounted) setState(() { _student = s; _loading = false; }); }
  Map<String, double> _scores(Map<String, dynamic> evals) {
    double a = 0, am = 0, b = 0, bm = 0;
    final academic = evals['academic'];
    if (academic is Map) { for (final subject in academic.values) { if (subject is Map) { for (final value in subject.values) { final n = int.tryParse('$value'); if (n != null && n >= 0 && n <= 2) { a += n; am += 2; } } } } }
    final behavioral = evals['behavioral'];
    if (behavioral is Map) { for (final group in behavioral.values) { if (group is Map) { for (final subgroup in group.values) { if (subgroup is Map) { for (final value in subgroup.values) { final n = int.tryParse('$value'); if (n != null && n >= 0 && n <= 2) { b += n; bm += 2; } } } } } } }
    final ap = am == 0 ? 0.0 : a / am * 100; final bp = bm == 0 ? 0.0 : b / bm * 100;
    final overall = am > 0 && bm > 0 ? (ap + bp) / 2 : (am > 0 ? ap : bp);
    return {'academic': ap, 'behavioral': bp, 'overall': overall};
  }
  Future<void> _edit() async { await Navigator.push(context, MaterialPageRoute(builder: (_) => StudentFormScreen(student: _student))); _load(); }
  Future<void> _delete() async { final yes = await showDialog<bool>(context: context, builder: (c) => AlertDialog(title: const Text('حذف التلميذ؟'), content: const Text('سيتم حذف سجل التلميذ من هذا الهاتف.'), actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('حذف'))])); if (yes == true) { await LocalDatabase.instance.deleteStudent(widget.studentId); if (mounted) Navigator.pop(context); } }
  Future<void> _saveEvaluations(Map<String, dynamic> updated) async { final s = _student!; await LocalDatabase.instance.saveStudent(s.copyWith(evaluations: updated, updatedAt: DateTime.now().toIso8601String())); await _load(); }
  Future<void> _snapshot() async {
    final s = _student!; final period = TextEditingController(text: 'الفصل الأول'); final year = TextEditingController(text: '2026/2027');
    final ok = await showDialog<bool>(context: context, builder: (c) => AlertDialog(title: const Text('حفظ لقطة تقييم'), content: Column(mainAxisSize: MainAxisSize.min, children: [TextField(controller: period, decoration: const InputDecoration(labelText: 'فترة التقييم')), TextField(controller: year, decoration: const InputDecoration(labelText: 'السنة الدراسية'))]), actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('حفظ'))]));
    if (ok != true || period.text.trim().isEmpty || year.text.trim().isEmpty) return;
    final history = [...s.history]; final snap = {'period': period.text.trim(), 'school_year': year.text.trim(), 'date': DateTime.now().toIso8601String().substring(0, 10), 'scores': _scores(s.evaluations), 'evaluations': {'academic': s.evaluations['academic'] ?? {}, 'behavioral': s.evaluations['behavioral'] ?? {}}};
    final i = history.indexWhere((e) => e is Map && e['period'] == snap['period'] && e['school_year'] == snap['school_year']); if (i >= 0) { history[i] = snap; } else { history.add(snap); }
    await LocalDatabase.instance.saveStudent(s.copyWith(history: history, updatedAt: DateTime.now().toIso8601String())); await _load();
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم حفظ لقطة التقييم في السجل التاريخي')));
  }
  Map<String, dynamic> _mergeSkills(Map<String, dynamic>? existing, List<String> defaults) { final out = <String, dynamic>{}; for (final k in defaults) { out[k] = existing?[k]; } if (existing != null) { for (final e in existing.entries) { out.putIfAbsent(e.key, () => e.value); } } return out; }

  Map<String, List<String>> _academicEntries(Map<String, dynamic> evals) {
    final result = <String, List<String>>{for (final e in defaultAcademic.entries) e.key: [...e.value]};
    final existing = evals['academic'];
    if (existing is Map) {
      for (final entry in existing.entries) {
        final skills = entry.value;
        if (skills is Map) {
          final list = result.putIfAbsent('${entry.key}', () => []);
          for (final skill in skills.keys) { if (!list.contains('$skill')) list.add('$skill'); }
        }
      }
    }
    return result;
  }

  Map<String, Map<String, List<String>>> _behaviorEntries(Map<String, dynamic> evals) {
    final result = <String, Map<String, List<String>>>{
      for (final e in defaultBehavior.entries)
        e.key: {for (final sub in e.value.entries) sub.key: [...sub.value]},
    };
    final existing = evals['behavioral'];
    if (existing is Map) {
      for (final group in existing.entries) {
        if (group.value is! Map) continue;
        final target = result.putIfAbsent('${group.key}', () => <String, List<String>>{});
        for (final sub in (group.value as Map).entries) {
          if (sub.value is! Map) continue;
          final skills = target.putIfAbsent('${sub.key}', () => <String>[]);
          for (final skill in (sub.value as Map).keys) { if (!skills.contains('$skill')) skills.add('$skill'); }
        }
      }
    }
    return result;
  }
  @override Widget build(BuildContext context) {
    if (_loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final s = _student; if (s == null) return const Scaffold(body: Center(child: Text('لم يتم العثور على التلميذ')));
    final scores = _scores(s.evaluations);
    return Scaffold(appBar: AppBar(title: const Text('بطاقة التلميذ'), actions: [IconButton(onPressed: _edit, icon: const Icon(Icons.edit_outlined)), IconButton(onPressed: _delete, icon: const Icon(Icons.delete_outline))]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(s.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), const SizedBox(height: 8), Text('${s.className} • ${s.gender}'), if (s.birthDate.isNotEmpty) Text('تاريخ الميلاد: ${s.birthDate}'), if (s.nationalId.isNotEmpty) Text('رقم التعريف: ${s.nationalId}'), if (s.notes.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Text(s.notes))]))),
        const SizedBox(height: 12), Row(children: [Expanded(child: _scoreCard('الأكاديمي', scores['academic']!)), const SizedBox(width: 8), Expanded(child: _scoreCard('السلوكي', scores['behavioral']!)), const SizedBox(width: 8), Expanded(child: _scoreCard('العام', scores['overall']!))]),
        const SizedBox(height: 20), Row(children: [const Expanded(child: Text('التقييم الأكاديمي', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))), TextButton.icon(onPressed: _snapshot, icon: const Icon(Icons.bookmark_add_outlined), label: const Text('حفظ الفترة'))]),
        ..._academicEntries(s.evaluations).entries.map((e) { final current = s.evaluations['academic'] is Map ? Map<String, dynamic>.from(s.evaluations['academic']) : <String, dynamic>{}; final values = current[e.key] is Map ? Map<String, dynamic>.from(current[e.key]) : <String, dynamic>{}; final skills = _mergeSkills(values, e.value); return _skillGroup(e.key, skills, (skill, value) { current[e.key] = {...values, skill: value}; final updated = Map<String, dynamic>.from(s.evaluations)..['academic'] = current; _saveEvaluations(updated); }); }),
        const SizedBox(height: 14), const Text('التقييم السلوكي', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        ..._behaviorEntries(s.evaluations).entries.map((group) { final root = s.evaluations['behavioral'] is Map ? Map<String, dynamic>.from(s.evaluations['behavioral']) : <String, dynamic>{}; final sub = root[group.key] is Map ? Map<String, dynamic>.from(root[group.key]) : <String, dynamic>{}; return Card(child: ExpansionTile(title: Text(group.key, style: const TextStyle(fontWeight: FontWeight.w600)), children: group.value.entries.map((subEntry) { final oldSkills = sub[subEntry.key] is Map ? Map<String, dynamic>.from(sub[subEntry.key]) : <String, dynamic>{}; return _skillGroup(subEntry.key, _mergeSkills(oldSkills, subEntry.value), (skill, value) { final updatedSub = {...sub, subEntry.key: {...oldSkills, skill: value}}; final updatedRoot = {...root, group.key: updatedSub}; final updated = Map<String, dynamic>.from(s.evaluations)..['behavioral'] = updatedRoot; _saveEvaluations(updated); }); }).toList())); }),
        const SizedBox(height: 18), const Text('السجل التاريخي', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        if (s.history.isEmpty) const Padding(padding: EdgeInsets.all(14), child: Text('لم تحفظ لقطات تقييم بعد.')) else ...s.history.map((h) { final m = h is Map ? h : {}; final sc = m['scores'] is Map ? m['scores'] : {}; return Card(child: ListTile(leading: const Icon(Icons.history), title: Text('${m['period'] ?? 'فترة'} • ${m['school_year'] ?? ''}'), subtitle: Text('التاريخ: ${m['date'] ?? ''}'), trailing: Text('${(double.tryParse('${sc['overall'] ?? sc['overall_percentage'] ?? 0}') ?? 0).toStringAsFixed(1)}%'))); }),
      ]));
  }
  Widget _scoreCard(String title, double value) => Card(child: Padding(padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 6), child: Column(children: [Text('${value.toStringAsFixed(0)}%', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Color(0xFF176B5B))), Text(title, style: const TextStyle(fontSize: 12, color: Colors.black54))])));
  Widget _skillGroup(String title, Map<String, dynamic> skills, void Function(String, int?) onChanged) => Card(child: ExpansionTile(title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)), children: skills.entries.map((e) { final value = int.tryParse('${e.value}'); return Padding(padding: const EdgeInsetsDirectional.fromSTEB(16, 0, 16, 10), child: Row(children: [Expanded(child: Text(e.key)), SizedBox(width: 155, child: DropdownButtonFormField<int?>(value: value, isExpanded: true, decoration: const InputDecoration(isDense: true, contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 8)), hint: const Text('لم يقيّم'), items: const [DropdownMenuItem<int?>(value: null, child: Text('لم يقيّم')), DropdownMenuItem<int?>(value: 0, child: Text('غير مكتسب')), DropdownMenuItem<int?>(value: 1, child: Text('في طريق الاكتساب')), DropdownMenuItem<int?>(value: 2, child: Text('مكتسب'))], onChanged: (v) => onChanged(e.key, v))) ])); }).toList()));
}
